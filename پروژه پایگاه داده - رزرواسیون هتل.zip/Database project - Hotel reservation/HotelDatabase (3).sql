/* Dorsa Farzaneh Ghasri - Paniz Kiani - Mahboubeh Sadat Hoseini - Saba Shaygani */
/* Our goal is to create five tables: Hotel, Room , Guest , Employee, Booking */

CREATE DATABASE hotel;
use hotel;

/************ Hotel Table ******************************************************************************************************/

CREATE TABLE Hotel (
    hotel_id INT NOT NULL,
    hotel_name VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    stars INT NOT NULL,
    PRIMARY KEY (hotel_id)
);

INSERT INTO Hotel( hotel_id, hotel_name, address, phone, stars) VALUES
(100100, 'Esteghlal', 'تهران ، تقاطع بزرگراه شهید چمران و ولی‌عصر، هتل بین المللی پارسیان استقلال' , '25-22660011-021', 5);
INSERT INTO Hotel( hotel_id, hotel_name, address, phone, stars) VALUES
(100101, 'Persian Plaza', 'تهران، سهروردی شمالی، چهارراه کیهان، خیابان میرزایی زینالی شرقی، پلاک ۴۲', '02186027813',5),
(100102, 'Espinas International', 'تهران، بلوار كشاورز، بین خیابان فلسطین و نادری، پلاک ۱۲۶', '02183844000',5),
(100103, 'Shahr', 'تهران، سه راه تهران پارس، اول خیابان دماوند، پلاک ۲۶۳', '02177700041',3),
(100104,'Bahar', 'تهران، بین پیچ شمیران و دروازه دولت، خیابان انقلاب، نبش خیابان بهار جنوبی، پلاک ۵', '02177502994',3);



/***************** Room table ****************************************************************************************************/
/* We have tried to simulate this data on our table: https://esteghlalhotel.ir/page/roomrates*/

CREATE TABLE Room(
room_id INT NOT NULL,
room_type VARCHAR(2) NOT NULL,	 /*room_type can be a "normal room with one bed(n1)" or a "normal room with two beds(n2)" a "normal swit(ns)" or a "royal swit(rs)"	*/
price FLOAT NOT NULL,
PRIMARY KEY(room_id)
);

/* hotel_id is added as foreign key to Room Table*/
ALTER TABLE Room
ADD COLUMN hotel_id INT;
ALTER TABLE Room 
ADD FOREIGN KEY (hotel_id) REFERENCES Hotel(hotel_id);


INSERT INTO Room (room_id, hotel_id, room_type, price) VALUES
(1, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'n1' , 5000000 ),
(2, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'n2' , 5500000),
(3, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'ns', 7900000),
(4, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'rs', 22100000),
(5, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'n1' , 5000000 ),
(6, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'n2' , 5500000),
(7, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'ns', 7900000),
(8, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'rs', 22100000),
(9, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'n2' , 5500000),
(10, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'n2' , 5500000);





/********************** Employee Table*************************************************************************************/

CREATE TABLE Employee(
emp_id INT NOT NULL,
first_name VARCHAR(53) NOT NULL,
last_name VARCHAR(53) NOT NULL,
national_code INT NOT NULL,
birth_date DATE NOT NULL,
gender VARCHAR(1) NOT NULL,
salary FLOAT NOT NULL,
PRIMARY KEY(emp_id)
);

/*adding a foreign key in this way, as we have already created the table*/
ALTER TABLE Employee
ADD COLUMN hotel_id INT;
ALTER TABLE Employee
ADD FOREIGN KEY (hotel_id) REFERENCES Hotel(hotel_id);


INSERT INTO Employee(emp_id, hotel_id, first_name, last_name, national_code, birth_date, gender, salary) VALUES
(100, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'Dave', 'Wallace', 123456, '1967-11-17', 'M', 250000 ),
(101,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'Jane','Levinson', 234567, '1961-05-11', 'F' , 110000),
(102,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'Micha', 'Scott', 345678, '1964-03-15', 'M', 75000),
(103, (SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'Angelina', 'Martin', 456789, '1971-06-25', 'F', 63000),
(104,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'Kily','Kapoor', 5678910, '1980-02-05', 'F', 55000),
(105,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'),'Stanley', 'Hudson',678945, '1958-02-19', 'M', 69000),
(106,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'James', 'Porter',678968, '1969-09-05', 'M', 78000),
(107,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'Andro', 'Bernard',689789, '1973-07-22', 'M', 65000),
(108,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'), 'Jimmy' , 'Hallpert', 698798, '1978-10-01' , 'M', 71000);




/*************************** Guest Table *********************************************************************/

CREATE TABLE Guest(
guest_id INT NOT NULL,
first_name VARCHAR(53) NOT NULL,
last_name VARCHAR(53) NOT NULL,
date_of_birth DATE,
phone VARCHAR(15) NOT NULL,
PRIMARY KEY(guest_id)
);


INSERT INTO Guest( guest_id, first_name, last_name, date_of_birth, phone) VALUES
(1201,'Sara', 'Jafari', '1999-05-12', '09122025458'),
(1202,'Mohammad', 'Noroozi', '1989-08-08', '0917856897'),
(1203,'Mina', 'Shafei','1978-07-04', '09122145678'),
(1204,'Ali', 'Peymoode', '1987-11-12','0913256487' ),
(1205,'Saba', 'Kia', '1984-04-01','09121456782'),
(1206,'Mahtab', 'Keramati','1974-05-14', '09125467892'),
(1207,'Jim', 'Halpert','1999-02-04','0917856492'),
(1208,'Sam','Karper','1968-08-09', '091216458984'),
(1209, 'Juliet', 'Pendelson', '1988-05-09', '0912978456'),
(1200, 'Robert', 'Aniston', '2000-05-10', '09132586497');



/************************Booking Table *****************************************************************************/


CREATE TABLE Booking(
booking_id INT NOT NULL,
guest_id INT NOT NULL,
room_id INT NOT NULL,
check_in_date DATE NOT NULL,
check_out_date DATE NOT NULL,
total_price float NOT NULL,
PRIMARY KEY (booking_id),
FOREIGN KEY (guest_id) REFERENCES Guest(guest_id),
FOREIGN KEY (room_id) REFERENCES Room(room_id)
);

/* Note that we have some guests booking for severla times, some booking at the same time*/
INSERT INTO roomBooking( booking_id, guest_id, room_id, check_in_date, check_out_date, total_price) VALUES
(300,(SELECT guest_id FROM Guest WHERE phone='09122025458') , (SELECT room_id FROM Room WHERE room_id =1) ,'2023-04-15', '2023-04-29', 5000000),
(301, (SELECT guest_id FROM Guest WHERE phone='0917856897' ), (SELECT room_id FROM Room WHERE room_id =2),'2023-05-18', '2023-05-25', 5500000),
(302, (SELECT guest_id FROM Guest WHERE phone='09122145678'), (SELECT room_id FROM Room WHERE room_id =3), '2023-05-18', '2023-05-25', 7900000),
(303,  (SELECT guest_id FROM Guest WHERE phone='09122145678'), (SELECT room_id FROM Room WHERE room_id =4),'2023-05-20', '2023-05-25', 22100000),
(304, (SELECT guest_id FROM Guest WHERE phone='09121456782'), (SELECT room_id FROM Room WHERE room_id =1), '2023-05-20', '2023-05-25', 5000000),
(305, (SELECT guest_id FROM Guest WHERE phone='09121456782'), (SELECT room_id FROM Room WHERE room_id =2), '2023-05-20', '2023-05-25', 5500000),
(306, (SELECT guest_id FROM Guest WHERE phone='09121456782'), (SELECT room_id FROM Room WHERE room_id =1), '2023-02-20', '2023-03-14', 5000000),
(307, (SELECT guest_id FROM Guest WHERE phone='09125467892'), (SELECT room_id FROM Room WHERE room_id =1), '2023-05-20', '2023-05-25', 5000000),
(308, (SELECT guest_id FROM Guest WHERE phone='0917856492'), (SELECT room_id FROM Room WHERE room_id =4), '2023-01-20', '2023-02-13', 22100000),
(309, (SELECT guest_id FROM Guest WHERE phone= '091216458984'), (SELECT room_id FROM Room WHERE room_id =2),'2023-05-18', '2023-05-25', 5500000),
(310, (SELECT guest_id FROM Guest WHERE phone= '0912978456'), (SELECT room_id FROM Room WHERE room_id =2), '2023-08-14', '2023-08-27', 5500000),
(311, (SELECT guest_id FROM Guest WHERE phone='09132586497'), (SELECT room_id FROM Room WHERE room_id =3), '2023-01-18', '2023-03-24', 7900000);

SELECT 
    *
FROM
    guest;


SELECT 
    *
FROM
    booking
ORDER BY room_id;


/*Suppose a device is found in one the rooms, name of Guest who have been in the shared rooms*/
SELECT 
    g.guest_id, b.room_id
FROM
    guest g
        LEFT JOIN
    booking b ON g.guest_id = b.guest_id
ORDER BY room_id ASC;



/*Name of guests who were in the hotel from February to May*/    
SELECT 
    g.first_name, g.last_name, b.room_id
FROM
    guest g
        LEFT JOIN
    booking b ON g.guest_id = b.guest_id
WHERE
    b.check_in_date > '2023-02-01'
        AND b.check_out_date < '2023-05-31'
ORDER BY room_id ASC;



/*Annual income of the hotel*/
SELECT 
    SUM(total_price) 'Annual Income'
FROM
    booking
ORDER BY booking_id;


/*Hotel income in May*/
SELECT 
    SUM(total_price) 'Income in May'
FROM
    booking
WHERE
    booking.check_in_date > '2023-05-01'
        AND booking.check_out_date <= '2023-05-31';


/*The number of days each guest stays in the hotel*/
SELECT 
    guest_id, SUM(check_out_date - check_in_date) 'Time'
FROM
    booking
GROUP BY guest_id
ORDER BY Time ASC;


/*Guests who are less thsn 40 years old*/
SELECT 
    guest_id, first_name, last_name
FROM
    guest
WHERE
    date_of_birth >= '1983-01-01'
ORDER BY date_of_birth ASC;