package TestHotel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class TestHotelDatabase {
	//building a connection from connection class to connect java to mysql database
	private static Connection connection = null;
	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		//object of class to call methods on it
		TestHotelDatabase testHotelDatabase= new TestHotelDatabase();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); //loads the driver
			System.out.println("Please enter your port number for mysql:");
			long port = scanner.nextLong();
			
			System.out.println("Please enter the database name you want to get data from:");
			String dbName = scanner.next();
			
			System.out.println("Please enter username for mysql:");
			String username = scanner.next();
			
			String dbURL = "jdbc:mysql://localhost:"+port+"/"+dbName;//connecting to mysql database and tables
			
			System.out.println("Please enter your password from mysql");
			String password = scanner.next();
			scanner.nextLine();
			
			connection = DriverManager.getConnection(dbURL, username, password);//connection to database
			boolean menu = true;
			while(menu) {
				System.out.println("__________________________________");
				System.out.println("Enter choice:");
				System.out.println("1. Insert record");
				System.out.println("2. Select a record");
				System.out.println("3. Select a table");
				System.out.println("4. update record");
				System.out.println("5. Delete a record");
				System.out.println("10. Exit");
				int choice = Integer.parseInt(scanner.nextLine());
				switch(choice) {
				case 1:
					testHotelDatabase.insertRecord();//method for inserting record
					break;
				case 2:
					testHotelDatabase.selectRecord();//select a record from a table
					break;
				case 3:
					testHotelDatabase.selectTable();//select a table from database
					break;
				case 4:
					testHotelDatabase.updateRecord();//update a record in a table
					break;
				case 5:
					testHotelDatabase.deleteRecord();//delete a record from guest table and booking table
					break;
				case 10:
					menu = false;
					System.out.println("__________________________________");
					break;	
				}
			}
		}catch (Exception e) {
			throw new RuntimeException("Something went wrong");
		}
	}
	
	private void insertRecord() throws SQLException {
		
		System.out.println("please enter table name");
		String table = scanner.nextLine();
		
		if(table.equals("employee")) {
			String sql = "insert into employee(emp_id, first_name, last_name, national_code, birth_date, gender, salary, hotel_id) values (?,?,?,?,?,?,?,(SELECT hotel_id FROM Hotel WHERE hotel_name = 'Esteghlal'))";//? is a place holder for the parameters
			PreparedStatement preparedStatement = connection.prepareStatement(sql);//helps to execute query from java
			
			//inserting values to table
			System.out.println("Enter id");
			preparedStatement.setInt(1, Integer.parseInt(scanner.nextLine()));
				
			System.out.println("Enter employee first name");
			preparedStatement.setString(2,scanner.nextLine());
				
			System.out.println("Enter employee last name");
			preparedStatement.setString(3,scanner.nextLine());
				
			System.out.println("Enter national code");
			preparedStatement.setInt(4, Integer.parseInt(scanner.nextLine()));
				
			System.out.println("Enter employee's date of birth");
			preparedStatement.setDate(5,java.sql.Date.valueOf(scanner.nextLine()));
				
			System.out.println("Enter employee's gender");
			preparedStatement.setString(6,scanner.nextLine());
			
			System.out.println("Enter employee's salary");
			preparedStatement.setFloat(7, Float.parseFloat(scanner.nextLine()));
				
			int rows = preparedStatement.executeUpdate();//shows the rows that are returned in sql
			if(rows > 0) {
				System.out.println("Record inserted successfully");
			}
		}
		else if(table.equals("guest")) {// inserting in guest table and booking table 
			String sql1 = "insert into guest(guest_id, first_name, last_name, date_of_birth, phone) values (?,?,?,?,?)";//? is a place holder for the parameters
			String sql2 = "INSERT INTO Booking( booking_id, guest_id, room_id, check_in_date, check_out_date, total_price) VALUES (?, (SELECT guest_id FROM Guest WHERE phone = ?),(SELECT room_id FROM Room WHERE room_id = ?),?,?,?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(sql1);
			PreparedStatement preparedStatement2 = connection.prepareStatement(sql2);
			
			System.out.println("Enter id");
			preparedStatement1.setInt(1, Integer.parseInt(scanner.nextLine()));
			
			System.out.println("Enter guest first name");
			preparedStatement1.setString(2,scanner.nextLine());
				
			System.out.println("Enter guest last name");
			preparedStatement1.setString(3,scanner.nextLine());
				
			System.out.println("Enter guest's date of birth");
			preparedStatement1.setDate(4,java.sql.Date.valueOf(scanner.nextLine()));
			
			System.out.println("Enter guest's phone");
			String phone = scanner.nextLine();
			preparedStatement1.setString(5,phone);
				
			int rows1 = preparedStatement1.executeUpdate();
			if(rows1 > 0) {
				System.out.println("Record inserted successfully into guest table");
			}
			
			System.out.println("Enter booking id");
			preparedStatement2.setInt(1, Integer.parseInt(scanner.nextLine()));
			preparedStatement2.setString(2,phone);
			
			System.out.println("Enter guest room id");
			preparedStatement2.setInt(3, Integer.parseInt(scanner.nextLine()));
			
			System.out.println("Enter check in date");
			preparedStatement2.setDate(4,java.sql.Date.valueOf(scanner.nextLine()));
			
			System.out.println("Enter check out date");
			preparedStatement2.setDate(5,java.sql.Date.valueOf(scanner.nextLine()));
			
			System.out.println("Enter total price");
			preparedStatement2.setFloat(6, Float.parseFloat(scanner.nextLine()));
			int rows2 = preparedStatement2.executeUpdate();
			if(rows2 > 0) {
				System.out.println("Record inserted successfully");
			}
		}	
	}

	private void selectRecord() throws SQLException{
		
		System.out.println("Enter the table name");
		String table = scanner.nextLine();
		String sql = null;
		
		if(table.equals("hotel")) {
			int ID = 0;
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter record's id");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where hotel_id = "+ID; //query to send to sql
		}
		
		if(table.equals("room")) {
			int ID = 0;
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter record's id");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where room_id = "+ID; //query
		}
		
		if(table.equals("employee")) {
			int ID = 0;
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter record's id");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where emp_id = "+ID; //query
		}
		
		if(table.equals("guest")) {
			int ID = 0;
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter record's id");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where guest_id = "+ID; //query
		}
		
		if(table.equals("booking")) {
			int ID = 0;
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter record's id");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where booking_id = "+ID;
		}
		
		Statement statement = connection.createStatement();//A statement is an interface that represents a SQL statement
		ResultSet result = statement.executeQuery(sql);//ResultSet is an object that represent a set of date returned
													   //from a data source -> as the result of a query
		if(result.next()){ //getting record's data from each table
			//the next() method iterate through each of the rows returned by the result set
			//moves the point in the current row to the next row in the result set
			if(table.equals("hotel")) {
				System.out.println("-------------------------------------------------------------------------------");
				int hotelId = result.getInt("hotel_id");
				String hotelName = result.getString("hotel_name");
				String address = result.getString("address");
				String phone = result.getString("phone");
				int stars = result.getInt("stars");
				System.out.println("|hotel_id: "+ hotelId +"\n"+"|hotel_name: "+ hotelName +"\n"+"|address: "+ address +"\n"+"|phone: " + phone+ "\n"+"|stars: "+ stars);
				System.out.println("-------------------------------------------------------------------------------");
			}
		
			else if(table.equals("room")) {
				System.out.println("room_id | room_type | price     | hotel_id");
				System.out.println("---------------------------------------------");
				int room_id = result.getInt("room_id");
				String room_type = result.getString("room_type");
				long price = result.getLong("price");
				int hotel_id = result.getInt("hotel_id");
			
				System.out.println(room_id +"\t|"+ room_type +"\t    |"+ price + "\t|"+ hotel_id);
				System.out.println("---------------------------------------------");
			}
			
			else if(table.equals("employee")) {
				System.out.println("------------------------------------------------------------------------------------------------------");
				
				int emp_id = result.getInt("emp_id");
				String first_name = result.getString("first_name");
				String last_name = result.getString("last_name");
				int national_code = result.getInt("national_code");
				String birth_date = result.getString("birth_date");
				String gender = result.getString("gender");
				long salary = result.getLong("salary");
				
				System.out.println("|emp_id: "+emp_id+"\n"+"|first_name: "+ first_name +"\n"+"|last_name: "+ last_name +"\n"+"|national_code: "+national_code+"\n"+"|birth_date: "+ birth_date+"\n"+"|gender: "+gender+"\n"+"|salary: "+salary );
				
				System.out.println("------------------------------------------------------------------------------------------------------");
			}
			
			else if(table.equals("guest")) {
				System.out.println("------------------------------------------------------------------------------------------------------");
				
				int guest_id = result.getInt("guest_id");
				String first_name = result.getString("first_name");
				String last_name = result.getString("last_name");
				String date_of_birth = result.getString("date_of_birth");
				String phone = result.getString("phone");
				
				System.out.println("|guest_id: "+guest_id+"\n"+"|first_name: "+ first_name +"\n"+"|last_name: "+ last_name +"\n"+"|date_of_birth: "+date_of_birth+"\n"+"|phone: "+phone );
				System.out.println("------------------------------------------------------------------------------------------------------");
			}
			
			else if(table.equals("booking")) {
				System.out.println("booking_id | guest_id | room_id | check_in_date | check_out_date | total_price");
				System.out.println("-------------------------------------------------------------------------------");
				int booking_id = result.getInt("booking_id");
				int guest_id = result.getInt("guest_id");
				int room_id  = result.getInt("room_id");
				String check_in_date = result.getString("check_in_date");
				String check_out_date = result.getString("check_out_date");
				long total_price = result.getLong("total_price");
				
				System.out.println(booking_id +"\t   |"+ guest_id +"      |"+ room_id + "        |"+ check_in_date + "\t|"+ check_out_date+ "\t|  "+ total_price);
				System.out.println("-------------------------------------------------------------------------------");
			}
		}
		
		else {
			System.out.println("No records found..");
		}
	}

	private void selectTable() throws SQLException{
		
		System.out.println("Enter the table name");
		String table = scanner.nextLine();
		
		String sql = "select * from "+ table; // query
		Statement statement = connection.createStatement(); // create a statement to represent a SQL statement
		ResultSet result = statement.executeQuery(sql); // execute the query -> returns one ResultSet object
								// Returns an integer representing the number of rows affected by the SQL statement.
		if(table.equals("hotel")) {
			System.out.println("-------------------------------------------------------------------------------");
			while(result.next()) {
				int hotelId = result.getInt("hotel_id");
				String hotelName = result.getString("hotel_name");
				String address = result.getString("address");
				String phone = result.getString("phone");
				int stars = result.getInt("stars");
				System.out.println("|hotel_id: "+ hotelId +"\n"+"|hotel_name: "+ hotelName +"\n"+"|address: "+ address +"\n"+"|phone: " + phone+ "\n"+"|stars: "+ stars);
				System.out.println("-------------------------------------------------------------------------------");
			}
		}
		else if(table.equals("room")) {
			System.out.println("room_id | room_type | price     | hotel_id");
			System.out.println("---------------------------------------------");
			
			while(result.next()) {
				int room_id = result.getInt("room_id");
				String room_type = result.getString("room_type");
				long price = result.getLong("price");
				int hotel_id = result.getInt("hotel_id");
				
				System.out.println(room_id +"\t|"+ room_type +"\t    |"+ price + "\t|"+ hotel_id);
				System.out.println("---------------------------------------------");
			}
		}
		else if(table.equals("employee")) {
			System.out.println("------------------------------------------------------------------------------------------------------");
			
			while(result.next()) {
				int emp_id = result.getInt("emp_id");
				String first_name = result.getString("first_name");
				String last_name = result.getString("last_name");
				int national_code = result.getInt("national_code");
				String birth_date = result.getString("birth_date");
				String gender = result.getString("gender");
				long salary = result.getLong("salary");
				
				System.out.println("|emp_id: "+emp_id+"\n"+"|first_name: "+ first_name +"\n"+"|last_name: "+ last_name +"\n"+"|national_code: "+national_code+"\n"+"|birth_date: "+ birth_date+"\n"+"|gender: "+gender+"\n"+"|salary: "+salary );
				
				System.out.println("------------------------------------------------------------------------------------------------------");
			}
		}
		
		else if(table.equals("guest")) {
			System.out.println("------------------------------------------------------------------------------------------------------");
			
			while(result.next()) {
				int guest_id = result.getInt("guest_id");
				String first_name = result.getString("first_name");
				String last_name = result.getString("last_name");
				String date_of_birth = result.getString("date_of_birth");
				String phone = result.getString("phone");
				
				System.out.println("|guest_id: "+guest_id+"\n"+"|first_name: "+ first_name +"\n"+"|last_name: "+ last_name +"\n"+"|date_of_birth: "+date_of_birth+"\n"+"|phone: "+phone );
				System.out.println("------------------------------------------------------------------------------------------------------");
			}
		}
		
		else if(table.equals("booking")) {
			System.out.println("booking_id | guest_id | room_id | check_in_date | check_out_date | total_price");
			System.out.println("-------------------------------------------------------------------------------");
			
			while(result.next()) {
				int booking_id = result.getInt("booking_id");
				int guest_id = result.getInt("guest_id");
				int room_id  = result.getInt("room_id");
				String check_in_date = result.getString("check_in_date");
				String check_out_date = result.getString("check_out_date");
				long total_price = result.getLong("total_price");
				
				System.out.println(booking_id +"\t   |"+ guest_id +"      |"+ room_id + "        |"+ check_in_date + "\t|"+ check_out_date+ "\t|  "+ total_price);
				System.out.println("-------------------------------------------------------------------------------");
			}
		}
		
		else {
			System.out.println("Table not found...");
		}
	}

	private void updateRecord() throws SQLException{
	
		System.out.println("Enter the table name:(choose between guest and booking table)");
		String table = scanner.nextLine();
		String sql = null;

		int ID = 0;
		if(table.equals("guest")) {
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter guest ID");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where guest_id = "+ID;//query
		}
		
		if(table.equals("booking")) {
			boolean t = true;
			while(t) {
				try {
					 System.out.println("Enter booking ID");
					 ID = Integer.parseInt(scanner.nextLine());
					 t = false;
				}catch (Exception e) {
					System.out.println("Please enter the id of the record you are looking for");
				}
			}
			sql = "select * from "+ table +" where booking_id = "+ID;//query
		}
		
		Statement statement = connection.createStatement();
		ResultSet result =  statement.executeQuery(sql);
		
		if(result.next()) {
			if(table.equals("guest")) {
				ID = result.getInt("guest_Id");
				String first_name = result.getString("first_name");
				String last_name = result.getString("last_name");
				String date_of_birth = result.getString("date_of_birth");
				String phone = result.getString("phone");
				
				System.out.println("|guest_id: "+ID+"\n"+"|first_name: "+ first_name +"\n"+"|last_name: "+ last_name +"\n"+"|date_of_birth: "+date_of_birth+"\n"+"|phone: "+phone );
				System.out.println("------------------------------------------------------------------------------------------------------");
		
				System.out.println("What do you want to updte?");
				System.out.println("1)Guest's first name");
				System.out.println("2)Guest's last name");
				System.out.println("3)Guest's date of birth");
				System.out.println("4)Guest's phone number");
				
				int choice = Integer.parseInt(scanner.nextLine());
				
				String sqlQuery = "update guest set ";
				switch (choice) {
				case 1://updating name
					System.out.println("Enter the new first name:");
					String newFirstName = scanner.nextLine(); 
					sqlQuery = sqlQuery + "first_name = ? where guest_Id = "+ID;
					PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
					preparedStatement.setString(1, newFirstName);
					int rows = preparedStatement.executeUpdate();
					if(rows > 0) {
						System.out.println("Record updated successfully.");
					}
					break;
				case 2://updating last name
					System.out.println("Enter the new last name:");
					String newLastName = scanner.nextLine(); 
					sqlQuery = sqlQuery + "last_name = ? where guest_Id = "+ID;
					PreparedStatement preparedStatement1 = connection.prepareStatement(sqlQuery);
					preparedStatement1.setString(1, newLastName);
					int rows1 = preparedStatement1.executeUpdate();
					if(rows1 > 0) {
						System.out.println("Record updated successfully.");
					}
					break;
				case 3://updating date of birth
					System.out.println("Enter the new date of birth:");
					String newDate = scanner.nextLine(); 
					sqlQuery = sqlQuery + "date_of_birth = ? where guest_Id = "+ID;
					PreparedStatement preparedStatement2 = connection.prepareStatement(sqlQuery);
					preparedStatement2.setString(1, newDate);
					int rows2 = preparedStatement2.executeUpdate();
					if(rows2 > 0) {
						System.out.println("Record updated successfully.");
					}
					break;
				case 4://updating phone
					System.out.println("Enter the new phone number:");
					String newphone = scanner.nextLine(); 
					sqlQuery = sqlQuery + "phone = ? where guest_Id = "+ID;
					PreparedStatement preparedStatement3 = connection.prepareStatement(sqlQuery);
					preparedStatement3.setString(1, newphone);
					int rows3 = preparedStatement3.executeUpdate();
					if(rows3 > 0) {
						System.out.println("Record updated successfully.");
					}
					break;
				}
			}
			
			if(table.equals("booking")) {
				ID = result.getInt("booking_Id");
				int guest_id = result.getInt("guest_id");
				int room_id = result.getInt("room_id");
				String check_in_date = result.getString("check_in_date");
				String check_out_date = result.getString("check_out_date");
				long total_price = result.getLong("total_price");
				
				System.out.println("booking_id | guest_id | room_id | check_in_date | check_out_date | total_price");
				System.out.println("-------------------------------------------------------------------------------");
				
				System.out.println(ID +"\t   |"+ guest_id +"      |"+ room_id + "        |"+ check_in_date + "\t|"+ check_out_date+ "\t|  "+ total_price);
				System.out.println("-------------------------------------------------------------------------------");
				System.out.println("What do you want to updte?");
				System.out.println("1)Room");
				System.out.println("2)Check out date");
				
				int choice = Integer.parseInt(scanner.nextLine());
				
				String sqlQuery = "update booking set ";
				switch (choice) {
				case 1://updating
					System.out.println("Enter the new room id:");
					String newRoomId = scanner.nextLine(); 
					sqlQuery = sqlQuery + "room_id = ? where booking_Id = "+ID;
					PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
					preparedStatement.setString(1, newRoomId);
					int rows = preparedStatement.executeUpdate();
					if(rows > 0) {
						System.out.println("Record updated successfully.");
					}
					break;
				case 2://updating check out date
					System.out.println("Enter the changed check out date:");
					String newCheckOut = scanner.nextLine(); 
					sqlQuery = sqlQuery + "check_out_date = ? where booking_Id = "+ID;
					PreparedStatement preparedStatement1 = connection.prepareStatement(sqlQuery);
					preparedStatement1.setString(1, newCheckOut);
					int rows1 = preparedStatement1.executeUpdate();
					if(rows1 > 0) {
						System.out.println("Record updated successfully.");
					}
					break;
				}
			}
		}
		else {
			System.out.println("Records not found...");
		}
	}

	public void deleteRecord() throws SQLException{
		System.out.println("Enter guest ID");
		int guest_id = Integer.parseInt(scanner.nextLine());
			
		String sql = "delete from booking where guest_id = "+guest_id;//query
		Statement statement = connection.createStatement();
		int rows = statement.executeUpdate(sql);//execute the query and returns number of rows
		if(rows> 0) {
			System.out.println("record is deleted successfully from guest table");
		}
			
		String sql1 = "delete from guest where guest_id = "+ guest_id;
		Statement statement1 = connection.createStatement();
		int rows1 = statement1.executeUpdate(sql1);
		if(rows1> 0) {
			System.out.println("record is deleted successfully from booking table");
		}
	}
}
